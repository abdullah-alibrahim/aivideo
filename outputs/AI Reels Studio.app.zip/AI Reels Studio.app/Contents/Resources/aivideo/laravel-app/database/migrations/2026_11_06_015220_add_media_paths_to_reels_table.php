<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('reels', function (Blueprint $table): void {
            $table->string('thumbnail_path')->nullable()->after('output_video_url');
            $table->string('subtitle_path')->nullable()->after('thumbnail_path');
        });
    }

    public function down(): void
    {
        Schema::table('reels', function (Blueprint $table): void {
            $table->dropColumn(['thumbnail_path', 'subtitle_path']);
        });
    }
};
